"use client";

import { useEffect, useState } from "react";
import { useGame } from "./GameContext";

type LeaderboardEntry = {
  rank: number;
  username: string;
  score: number;
};

export default function Leaderboard({
                                      id: initial = "all",
                                      limit = 5,
                                      tabs = false,
                                      linked = false,
                                    }: {
  id?: string;
  limit?: number;
  tabs?: boolean;
  linked?: boolean;
}) {
  const { score, user, blockId } = useGame();
  const [local, setId] = useState(initial);
  const id = linked ? blockId : local;

  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [blocks, setBlocks] = useState<{ id: string; name: string }[]>([]);

  useEffect(() => {
    if (tabs) {
      fetch("/api/blocks")
          .then((res) => res.json())
          .then(setBlocks)
          .catch(() => {});
    }
  }, [tabs]);

  useEffect(() => {
    fetch(`/api/leaderboard?block=${id}&limit=${limit}`)
        .then((res) => res.json())
        .then((data) => setEntries(data.entries || []))
        .catch(() => setEntries([]));
  }, [id, limit, score]);

  const currentBlockName =
      id === "all"
          ? "All Blocks"
          : blocks.find((b) => b.id === id)?.name || id.charAt(0).toUpperCase() + id.slice(1);

  return (
      <div className="bg-[#12121a] border border-[#232336] rounded-2xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-white text-base">
            {currentBlockName} Leaderboard
          </h3>
          <span className="text-xs font-mono text-slate-500">Top {limit}</span>
        </div>

        {tabs && !linked && (
            <div className="flex gap-1.5 mb-4 overflow-x-auto pb-1">
              {[{ id: "all", name: "All" }, ...blocks].map((b) => (
                  <button
                      key={b.id}
                      onClick={() => setId(b.id)}
                      className={`py-1 px-2.5 rounded font-mono text-xs whitespace-nowrap transition ${
                          local === b.id
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                              : "bg-[#181824] text-slate-400 hover:text-white border border-transparent"
                      }`}
                  >
                    {b.name}
                  </button>
              ))}
            </div>
        )}

        <div className="space-y-2">
          {entries.length === 0 ? (
              <div className="text-center py-6 text-slate-500 font-mono text-xs">
                No scores yet.
              </div>
          ) : (
              entries.map((entry) => (
                  <div
                      key={entry.rank}
                      className={`flex items-center justify-between p-2.5 rounded-lg border font-mono text-xs ${
                          user && user.username === entry.username
                              ? "bg-emerald-950/20 border-emerald-500/30 text-emerald-300"
                              : "bg-[#161622] border-[#222233] text-slate-300"
                      }`}
                  >
                    <div className="flex items-center gap-2">
                <span className="text-slate-500 font-semibold w-5">
                  #{entry.rank}
                </span>
                      <span className="font-medium">{entry.username}</span>
                    </div>
                    <span className="font-bold">{entry.score} score</span>
                  </div>
              ))
          )}
        </div>
      </div>
  );
}