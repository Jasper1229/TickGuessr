"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Timer } from "lucide-react";
import { useGame } from "./GameContext";
import { play } from "@/lib/sfx";

type Round = {
  roundId: string;
  imageUrl: string;
  blockName: string;
  totalSheets: number;
  sheetLabels?: string[];
};

type Result = {
  correct: boolean;
  scoreDelta: number;
  actualSheet: number;
  actualFrame: number;
};

export default function Game() {
  const { score, setScore, streak, setStreak, muted, user, blockId, setBlockId } = useGame();

  const [blocks, setBlocks] = useState<{ id: string; name: string }[]>([]);
  const [round, setRound] = useState<Round | null>(null);
  const [sheet, setSheet] = useState<number>(0);
  const [frame, setFrame] = useState<string>("");
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [locked, setLocked] = useState(false);
  const [result, setResult] = useState<Result | null>(null);

  const frameInputRef = useRef<HTMLInputElement>(null);

  const apply = useCallback((r: Round) => {
    setRound(r);
    setSheet((s) => (s < r.totalSheets ? s : 0));
    setFrame("");
    setTimeLeft(60);
    setLocked(false);
    setResult(null);
    setTimeout(() => frameInputRef.current?.focus(), 50);
  }, []);

  async function fetchRound(targetBlock: string): Promise<Round> {
    const r: Round = await (
        await fetch(`/api/round?block=${targetBlock}`, { cache: "no-store" })
    ).json();
    new Image().src = r.imageUrl;
    return r;
  }

  useEffect(() => {
    fetch("/api/blocks")
        .then((res) => res.json())
        .then(setBlocks)
        .catch(() => {});
  }, []);

  useEffect(() => {
    let live = true;
    fetchRound(blockId).then((r) => {
      if (live) apply(r);
    });
    return () => {
      live = false;
    };
  }, [apply, blockId]);

  useEffect(() => {
    if (locked) return;
    const interval = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(interval);
          submit(true);
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [locked]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (locked) return;
      const target = e.target as HTMLElement;
      if (target.tagName === "INPUT" && target.id === "frameInput") return;

      if (e.key === "a" || e.key === "A") {
        setSheet(0);
      } else if (e.key === "s" || e.key === "S") {
        if ((round?.totalSheets ?? 1) > 1) {
          setSheet(1);
        }
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [locked, round?.totalSheets]);

  const submit = async (timeout = false) => {
    if (locked || !round) return;
    setLocked(true);

    const f = timeout ? -1 : parseInt(frame, 10);
    const validFrame = Number.isInteger(f) ? f : 0;

    const res = await fetch("/api/guess", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        roundId: round.roundId,
        sheet,
        frame: validFrame,
        timeRemaining: timeLeft,
      }),
    });

    if (!res.ok) {
      apply(await fetchRound(blockId));
      return;
    }

    const data: Result = await res.json();
    setResult(data);

    if (data.correct) {
      if (!muted) play("correct");
      setScore((s) => s + data.scoreDelta);
      setStreak((s) => s + 1);
    } else {
      if (!muted) play("wrong");
      setStreak(0);
    }

    const next = fetchRound(blockId);
    setTimeout(async () => {
      apply(await next);
    }, 1800);
  };

  return (
      <div className="bg-[#12121a] border border-[#232336] rounded-2xl p-6 shadow-xl relative overflow-hidden">
        {blocks.length > 1 && (
            <div className="flex flex-wrap justify-center gap-2 mb-5">
              {[{ id: "all", name: "All" }, ...blocks].map((b) => (
                  <button
                      key={b.id}
                      type="button"
                      disabled={locked}
                      onClick={() => setBlockId(b.id)}
                      className={`py-1.5 px-4 rounded-lg font-mono text-xs transition disabled:opacity-60 ${
                          blockId === b.id
                              ? "font-bold bg-[#1b2f27] border-2 border-emerald-400 text-emerald-300"
                              : "font-semibold bg-[#212130] hover:bg-[#28283a] border border-transparent text-slate-300"
                      }`}
                  >
                    {b.name}
                  </button>
              ))}
            </div>
        )}

        <div className="text-center mb-4">
          <h2 className="text-xl font-bold text-white mb-1">
            What sprite sheet &amp; tick is this?
          </h2>
          <p className="text-sm text-slate-400">
            Block: <span className="font-semibold text-emerald-400">{round?.blockName || "..."}</span>
          </p>
        </div>

        <div className="flex flex-col items-center justify-center mb-6">
          <div className="w-32 h-32 bg-[#1b1b26] border-2 border-[#2b2b3d] rounded-xl flex items-center justify-center overflow-hidden [image-rendering:pixelated]">
            {round ? (
                <img
                    src={round.imageUrl}
                    alt="Texture frame"
                    className="w-full h-full object-contain [image-rendering:pixelated]"
                />
            ) : (
                <div className="w-6 h-6 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
            )}
          </div>
        </div>

        <form
            onSubmit={(e) => {
              e.preventDefault();
              submit();
            }}
            className="space-y-4 max-w-sm mx-auto"
        >
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1 text-center">
              1. Select Sprite Sheet <span className="text-slate-500">(keys: a / s)</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              {Array.from({ length: round?.totalSheets || 2 }).map((_, idx) => {
                const label =
                    round?.sheetLabels && round.sheetLabels[idx]
                        ? round.sheetLabels[idx]
                        : `SHEET ${idx}`;
                return (
                    <button
                        key={idx}
                        type="button"
                        disabled={locked}
                        onClick={() => setSheet(idx)}
                        className={`py-2 px-3 rounded-lg font-mono text-xs uppercase border transition ${
                            sheet === idx
                                ? "border-emerald-400 bg-emerald-950/40 text-emerald-300 font-bold"
                                : "border-[#28283d] bg-[#1a1a26] text-slate-400 hover:border-slate-500"
                        }`}
                    >
                      {label}
                    </button>
                );
              })}
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1 text-center">
              2. Enter Frame Number (0-31)
            </label>
            <input
                id="frameInput"
                ref={frameInputRef}
                type="number"
                min={0}
                max={31}
                value={frame}
                disabled={locked}
                onChange={(e) => setFrame(e.target.value)}
                placeholder="0"
                className="w-full bg-[#161622] border border-[#2b2b3d] rounded-lg py-2 px-3 text-center font-mono text-lg text-white focus:outline-none focus:border-emerald-500"
                required
            />
          </div>

          <button
              type="submit"
              disabled={locked || frame === ""}
              className="w-full py-2.5 rounded-lg bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-slate-950 font-bold font-mono text-sm transition"
          >
            Submit Guess
          </button>
        </form>

        {result && (
            <div
                className={`mt-4 p-3 rounded-lg text-center font-mono text-xs border ${
                    result.correct
                        ? "bg-emerald-950/60 border-emerald-500/50 text-emerald-300"
                        : "bg-rose-950/60 border-rose-500/50 text-rose-300"
                }`}
            >
              {result.correct ? (
                  <div>Correct! +{result.scoreDelta} pts</div>
              ) : (
                  <div>
                    Incorrect! Was Sheet {result.actualSheet}, Frame {result.actualFrame}
                  </div>
              )}
            </div>
        )}

        <div className="flex items-center justify-between mt-6 pt-4 border-t border-[#232336] text-xs font-mono text-slate-400">
          <div className="flex items-center gap-1.5">
            <Timer className="w-4 h-4 text-emerald-400" />
            <span>{String(timeLeft).padStart(2, "0")}s</span>
          </div>
          <div>
            SCORE: <span className="text-white font-bold">{score}</span>
          </div>
        </div>
      </div>
  );
}