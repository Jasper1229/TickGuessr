import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { getBlocks } from "@/lib/registry";
import { rounds, prune } from "@/lib/rounds";

export async function GET(req: Request) {
    prune();

    const { searchParams } = new URL(req.url);
    const blockParam = searchParams.get("block") || "all";

    const allBlocks = await getBlocks();
    if (!allBlocks.length) {
        return NextResponse.json({ error: "No blocks available" }, { status: 404 });
    }

    const eligibleBlocks =
        blockParam === "all"
            ? allBlocks
            : allBlocks.filter((b) => b.id === blockParam);

    const activeBlocks = eligibleBlocks.length > 0 ? eligibleBlocks : allBlocks;
    const chosenBlock = activeBlocks[Math.floor(Math.random() * activeBlocks.length)];

    if (!chosenBlock.sheets.length) {
        return NextResponse.json({ error: "No sheets for block" }, { status: 400 });
    }

    const sheetIndex = Math.floor(Math.random() * chosenBlock.sheets.length);
    const frameIndex = Math.floor(Math.random() * 32);
    const flip = Math.random() < 0.5;

    const roundId = randomUUID();
    rounds.set(roundId, {
        block: chosenBlock.id,
        sheet: sheetIndex,
        frame: frameIndex,
        flip,
        start: Date.now(),
        guesses: 0,
    });

    const sheetLabels = chosenBlock.sheets.map((s: { file: string }) =>
        s.file.replace(/\.png$/, "")
    );

    return NextResponse.json(
        {
            roundId,
            imageUrl: `/api/round/${roundId}/image`,
            blockName: chosenBlock.name,
            totalSheets: chosenBlock.sheets.length,
            sheetLabels,
        },
        { headers: { "Cache-Control": "no-store" } }
    );
}