import Game from "@/components/Game";
import Leaderboard from "@/components/Leaderboard";

export default function Home() {
    return (
        <div className="max-w-6xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            <div className="lg:col-span-8">
                <Game />
            </div>
            <div className="lg:col-span-4">
                <Leaderboard linked />
            </div>
        </div>
    );
}